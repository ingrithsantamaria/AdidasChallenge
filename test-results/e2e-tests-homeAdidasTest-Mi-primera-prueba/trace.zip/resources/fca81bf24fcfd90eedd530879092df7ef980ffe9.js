try{var trackingServer="https://prf.hn";var localStorageKey="_pz_clickref";}catch(e){}try{function getUrlParam(name,url){var parameters=new RegExp('[\?&]'+name+'=([^&#]*)').exec(url);return parameters?decodeURI(parameters[1]):null;}
function getUrlSection(name,url){var sections=new RegExp('/'+name+':([^/?]*)').exec(url);return sections?decodeURI(sections[1]):null;}
var camref=getUrlParam('pcamref',window.location.search);var source=getUrlParam('psrc',window.location.search);if(source==='pz'&&camref){var request=new XMLHttpRequest();var url=trackingServer+'/click/camref:'+camref+'/mode:json';request.open("GET",url);request.onload=function(){if(request.status===200&&request.responseText){var response=JSON.parse(request.responseText);localStorage.setItem(localStorageKey,response.clickref)}};request.send();}}
catch(e){}try{var pixel_key='_pz_clickref';function getUrlParam(name,url){var parameters=new RegExp('[\?&]'+name+'=([^&#]*)').exec(url);return parameters?decodeURI(parameters[1]):null;}
function getUrlSection(name,url){var sections=new RegExp('/'+name+':([^/?]*)').exec(url);return sections?decodeURI(sections[1]):null;}
function getCookie(name){var match=document.cookie.match(new RegExp('(^| )'+name+'=([^;]+)'));if(match)return match[2];}
function setCookie(name,value){var date=new Date();date.setFullYear(date.getFullYear()+1);var expires=";expires="+date.toUTCString();var domain=window.location.hostname.match(/^(?:.*?\.)?([a-zA-Z0-9\-_]{3,}\.(?:\w{2,8}|\w{2,4}\.\w{2,4}))$/)[1];document.cookie=name+"="+(value||"")+expires+";domain=."+domain+";path=/";}
var clickref=getUrlParam('clickref',window.location.href);if(clickref){localStorage[pixel_key]=clickref;setCookie(pixel_key,clickref);}
var pixel_element=document.querySelector("div[data-partnerize]")
if(pixel_element){var pixel_url=pixel_element.getAttribute('data-partnerize')
var stored_clickref=localStorage[pixel_key]||getCookie(pixel_key)
if(stored_clickref){var pixel_clickref=getUrlSection('clickref',pixel_url);if(pixel_clickref)
pixel_url=pixel_url.replace('/clickref:'+pixel_clickref,'');pixel_url+='/clickref:'+stored_clickref;}
var pixel=document.createElement('img');pixel.src=pixel_url;pixel.style.display='none';pixel.onload=function(){document.body.removeChild(pixel);}
document.body.appendChild(pixel);}}
catch(e){}